#include <stdio.h>
int main() {
   // your code goes here
   cout << "hellp\n";
   return 0;
}