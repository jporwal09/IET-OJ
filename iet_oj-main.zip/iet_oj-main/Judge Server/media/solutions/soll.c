#include <stdio.h>
int main()
{
    int a,b;
    
    scanf("%d %d",&a,&b);
    int sum=a+b;
    printf("%d\n",sum);
    return 0;
}