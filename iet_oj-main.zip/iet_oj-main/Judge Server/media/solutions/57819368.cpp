#include <bits/stdc++.h>
using namespace std;
int main() {
   butnys is 
   return 0;
}
