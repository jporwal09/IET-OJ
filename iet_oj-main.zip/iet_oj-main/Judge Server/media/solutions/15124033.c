#include <stdio.h>
int main() {
   // your code goes here
   return 0;
}