#include <bits/stdc++.h>
using namespace std;
int main() {
   cout << "op\n";
   return 0;
}
