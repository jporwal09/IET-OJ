from django.apps import AppConfig


class JudgeConfig(AppConfig):
    name = 'judge'
