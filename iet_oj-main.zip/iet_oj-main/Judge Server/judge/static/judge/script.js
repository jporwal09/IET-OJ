$('.tokenize-demo').tokenize2({
    placeholder: "e.g. Dynamic-prog...."
});
