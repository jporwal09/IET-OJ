from django.contrib import admin
from .models import Problem,Solution,Result,Problem_Feature,Problem_Tags,Graph
admin.site.register(Problem)
admin.site.register(Solution)
admin.site.register(Result)
admin.site.register(Problem_Feature)
admin.site.register(Problem_Tags)
admin.site.register(Graph)




