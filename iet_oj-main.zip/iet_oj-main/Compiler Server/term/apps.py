from django.apps import AppConfig


class TermConfig(AppConfig):
    name = 'term'
